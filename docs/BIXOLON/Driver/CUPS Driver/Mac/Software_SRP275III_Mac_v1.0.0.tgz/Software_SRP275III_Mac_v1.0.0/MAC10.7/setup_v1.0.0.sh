#!/bin/sh

echo "BIXOLON Co., Ltd."
echo "BIXOLON SRP-275III CUPS DRIVER V1.0.0 Mac OS Installer"
echo "---------------------------------------"
echo ""
echo "Models included:"

echo "                    SRP-275III"
echo ""

ROOT_UID=0

if [ "$UID" -ne "$ROOT_UID" ]
then
    echo "This script requires root user access..."
    echo "Re-run as root user..."
    exit 1
fi

echo "Copying rastertoSRP275III_v1.0.0 filter..."
 sudo chmod +x rastertoSRP275III_v1.0.0
 sudo cp ./rastertoSRP275III_v1.0.0 /usr/libexec/cups/filter/
 sudo chmod 0755 /usr/libexec/cups/filter/rastertoSRP275III_v1.0.0
echo ""

sudo cp /usr/libexec/cups/filter/cgbannertopdf /usr/libexec/cups/filter/cgbannertopdf_org_backup
sudo mv /usr/libexec/cups/filter/cgbannertopdf /usr/libexec/cups/filter/cgbannertopdf_org
sudo cp ./cgbannertopdf /usr/libexec/cups/filter/cgbannertopdf
sudo chmod +x /usr/libexec/cups/filter/cgbannertopdf

echo "Copying model ppd files... "
   sudo cp -Rv ../SRP275III_v1.0.0.ppd /usr/share/cups/model/ 
echo ""

echo "Restarting CUPS"
    sudo launchctl  unload /System/Library/LaunchDaemons/org.cups.cupsd.plist
     sudo launchctl load /System/Library/LaunchDaemons/org.cups.cupsd.plist
    echo ""

echo "Install Complete"
echo "Add printer queue using OS tool, http://localhost:631, or http://127.0.0.1:631"
echo ""

