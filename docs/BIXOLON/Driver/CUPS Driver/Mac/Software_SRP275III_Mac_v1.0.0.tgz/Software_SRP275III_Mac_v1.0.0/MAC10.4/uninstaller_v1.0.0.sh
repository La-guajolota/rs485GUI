#!/bin/sh

echo "Bixolon CO Ltd"
echo "BIXOLON SRP-275II CUPS DRIVER V1.0.0 Mac OS Uninstaller"
echo "---------------------------------------"
echo ""
echo "Models Uninstalled:"

echo "                    SRP-275II"
echo ""

ROOT_UID=0

if [ "$UID" -ne "$ROOT_UID" ]
then
    echo "This script requires root user access..."
    echo "Re-run as root user..."
    exit 1
fi

echo "Removing filter..."
sudo rm -v /usr/libexec/cups/filter/rastertoSRP275II*
echo " "

echo "Removing PPD..."
sudo rm -v /usr/share/cups/model/BIXOLON/SRP275II*
sudo rmdir /usr/share/cups/model/BIXOLON
echo " "


echo "Removing Pkg..."
 sudo rm -frv /Library/Receipts/BIXOLON*..*.*.pkg
echo ""

echo "Restarting CUPS"
    sudo launchctl  unload /System/Library/LaunchDaemons/org.cups.cupsd.plist
    sudo launchctl load /System/Library/LaunchDaemons/org.cups.cupsd.plist
    echo ""

echo "Uninstall Complete"
echo "Delete printer queue using OS tool, http://localhost:631, or http://127.0.0.1:631"
echo ""

