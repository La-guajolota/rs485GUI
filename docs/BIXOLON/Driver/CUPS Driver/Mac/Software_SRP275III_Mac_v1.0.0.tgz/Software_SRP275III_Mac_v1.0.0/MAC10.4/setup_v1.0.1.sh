#!/bin/sh

echo "BIXOLON Co., Ltd."
echo "BIXOLON SRP-275II CUPS DRIVER V1.0.1 Mac OS Installer"
echo "---------------------------------------"
echo ""
echo "Models included:"

echo "                    SRP-275II"
echo ""

ROOT_UID=0

if [ "$UID" -ne "$ROOT_UID" ]
then
    echo "This script requires root user access..."
    echo "Re-run as root user..."
    exit 1
fi

echo "Copying rastertoSRP275II_v1.0.0 filter..."



 sudo chmod +x rastertoSRP275II_v1.0.0
 sudo cp ./rastertoSRP275II_v1.0.0 /usr/libexec/cups/filter/
 sudo chmod 0755 /usr/libexec/cups/filter/rastertoSRP275II_v1.0.0
echo ""

echo "Copying model ppd files... "
   sudo cp -Rv ../SRP275II_v1.0.0.ppd /usr/share/cups/model/ 
echo ""

echo "Restarting CUPS"
    sudo launchctl  unload /System/Library/LaunchDaemons/org.cups.cupsd.plist
     sudo launchctl load /System/Library/LaunchDaemons/org.cups.cupsd.plist
    echo ""

echo "Install Complete"
echo "Add printer queue using OS tool, http://localhost:631, or http://127.0.0.1:631"
echo ""

