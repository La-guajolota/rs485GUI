#!/bin/sh
echo ""
echo "---------------------------------------------------------"
echo "        BIXOLON CO LTD"
echo "BIXOLON SRP-275III CUPS DRIVER V1.0.0 Installer"
echo "---------------------------------------------------------"
echo ""
echo "Models included:"

echo "                 SRP-275II"
echo ""

ROOT_UID=0

if [ "$UID" -ne "$ROOT_UID" ]
then
    echo "This script requires root user access..."
    echo "Re-run as root user..."
    exit 1
fi

echo "Copying rastertoSRP275III_v1.0.0 filter..."

sudo chmod +x rastertoSRP275III_v1.0.0
sudo cp ./rastertoSRP275III_v1.0.0 /usr/bin/
sudo chmod 0755 /usr/bin/rastertoSRP275III_v1.0.0
echo ""

echo "Creating Symbolic Link...."
sudo ln -s --target-directory=/usr/lib/cups/filter/ /usr/bin/rastertoSRP275III_v1.0.0
sudo chmod 0755 /usr/lib/cups/filter/rastertoSRP275III_v1.0.0
echo ""

echo "Copying model ppd files... "
sudo chmod +x SRP275III_v1.0.0.ppd

if [ -x /etc/init.d/cupsys ]
then
	if [ -r /etc/debian_version ]
	then
		if [ -r /etc/lsb-release ]
		then
			if [ -r /usr/share/cups/model ]
			then
				sudo cp ./SRP275III_v1.0.0.ppd /usr/share/cups/model/
				sudo chmod 0755 /usr/share/cups/model/SRP275III_v1.0.0.ppd
			else
				sudo cp ./SRP275III_v1.0.0.ppd /usr/share/ppd/ 
				sudo chmod 0755 /usr/share/ppd/SRP275III_v1.0.0.ppd
			fi
		else
			 sudo cp ./SRP275III_v1.0.0.ppd /usr/share/ppd/ 
			 sudo chmod 0755 /usr/share/ppd/SRP275III_v1.0.0.ppd
			 
		fi
	else
		 sudo cp ./SRP275III_v1.0.0.ppd /usr/share/cups/model/ 
		 sudo chmod 0755 /usr/share/cups/model/SRP275III_v1.0.0.ppd
		 
	fi
else
	if [ -r /etc/debian_version ]
	then
		 sudo cp ./SRP275III_v1.0.0.ppd /usr/share/ppd/ 
		 sudo chmod 0755 /usr/share/ppd/SRP275III_v1.0.0.ppd
		
	else
		 sudo cp ./SRP275III_v1.0.0.ppd /usr/share/cups/model/ 
		 sudo chmod 0755 /usr/share/cups/model/SRP275III_v1.0.0.ppd
		
	fi
fi 

sudo service cups stop
sudo service cups start

echo ""

echo "Restarting CUPS"
    if [ -x /etc/software/init.d/cups ]
    then
        sudo /etc/software/init.d/cups stop
        sudo /etc/software/init.d/cups start
    elif [ -x /etc/rc.d/init.d/cups ]
    then
        sudo /etc/rc.d/init.d/cups stop
        sudo /etc/rc.d/init.d/cups start
    elif [ -x /etc/rc.d/rc.cups ]
    then
        sudo /etc/rc.d/rc.cups stop
        sudo /etc/rc.d/rc.cups start        
    elif [ -x /etc/init.d/cups ]
    then
        sudo /etc/init.d/cups stop
        sudo /etc/init.d/cups start
    elif [ -x /sbin/init.d/cups ]
    then
        sudo /sbin/init.d/cups stop
        sudo /sbin/init.d/cups start
    elif [ -x /etc/software/init.d/cupsys ]
    then
        sudo /etc/software/init.d/cupsys stop
        sudo /etc/software/init.d/cupsys start
    elif [ -x /etc/rc.d/init.d/cupsys ]
    then
        sudo /etc/rc.d/init.d/cupsys stop
        sudo /etc/rc.d/init.d/cupsys start
    elif [ -x /etc/init.d/cupsys ]
    then
        sudo /etc/init.d/cupsys stop
        sudo /etc/init.d/cupsys start
    elif [ -x /sbin/init.d/cupsys ]
    then
        sudo /sbin/init.d/cupsys stop
        sudo /sbin/init.d/cupsys start
    else
        echo "Could not restart CUPS"
    fi

    sudo service cups stop
    sudo service cups start

    echo ""

echo "Install Complete"
echo "Add printer queue using OS tool, http://localhost:631, or http://127.0.0.1:631"
echo ""

