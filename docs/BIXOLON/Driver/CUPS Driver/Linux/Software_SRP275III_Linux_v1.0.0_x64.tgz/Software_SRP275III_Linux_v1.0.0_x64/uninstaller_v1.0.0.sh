#!/bin/sh
echo ""
echo "---------------------------------------------------------"
echo "        BIXOLON CO LTD"
echo "BIXOLON SRP-275III CUPS DRIVER V1.0.0 Uninstaller"
echo "---------------------------------------------------------"
echo ""
echo "Models Uninstalled:"

echo "                 SRP-275III"
echo ""

ROOT_UID=0

if [ "$UID" -ne "$ROOT_UID" ]
then
    echo "This script requires root user access..."
    echo "Re-run as root user..."
    exit 1
fi

echo "Removing rastertoSRP275III filter..."

sudo rm -f /usr/bin/rastertoSRP275III*
sudo rm -f /usr/lib/cups/filter/rastertoSRP275III*
echo ""

echo "Removing model ppd files... "
sudo rm -f /usr/share/cups/model/SRP275III*
sudo rm -f /usr/share/ppd/SRP275III*


echo ""
echo "Restarting CUPS"
    if [ -x /etc/software/init.d/cups ]
    then
        sudo /etc/software/init.d/cups stop
        sudo /etc/software/init.d/cups start
    elif [ -x /etc/rc.d/init.d/cups ]
    then
        sudo /etc/rc.d/init.d/cups stop
        sudo /etc/rc.d/init.d/cups start
    elif [ -x /etc/rc.d/rc.cups ]
    then
        sudo /etc/rc.d/rc.cups stop
        sudo /etc/rc.d/rc.cups start
    elif [ -x /etc/init.d/cups ]
    then
        sudo /etc/init.d/cups stop
        sudo /etc/init.d/cups start
    elif [ -x /sbin/init.d/cups ]
    then
        sudo /sbin/init.d/cups stop
        sudo /sbin/init.d/cups start
    elif [ -x /etc/software/init.d/cupsys ]
    then
        sudo /etc/software/init.d/cupsys stop
        sudo /etc/software/init.d/cupsys start
    elif [ -x /etc/rc.d/init.d/cupsys ]
    then
        sudo /etc/rc.d/init.d/cupsys stop
        sudo /etc/rc.d/init.d/cupsys start
    elif [ -x /etc/init.d/cupsys ]
    then
        sudo /etc/init.d/cupsys stop
        sudo /etc/init.d/cupsys start
    elif [ -x /sbin/init.d/cupsys ]
    then
        sudo /sbin/init.d/cupsys stop
        sudo /sbin/init.d/cupsys start
    else
        echo "Could not restart CUPS"
    fi
    sudo service cups stop
    sudo service cups start
    echo ""

echo "Uninstall Complete"
echo "Delete printer queue using OS tool, http://localhost:631, or http://127.0.0.1:631"
echo ""
